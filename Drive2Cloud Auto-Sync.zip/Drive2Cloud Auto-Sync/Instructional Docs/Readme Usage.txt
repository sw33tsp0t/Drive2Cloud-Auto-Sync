if you have enough cloud space for your external harddrive, heres a simple way to dynamically back up all your data on that drive path & folder
without having to do it manually, and will backup everytime automatically to the cloud (dropbox) everytime you change a file or add a file.
But I must tell you, you need high cloud space, Dropbox free is only 2GB, you will at least need the 1tb cloud storage plan.
for 2gb Free Plan I Reccommend Syncing Gamesave Paths.

Step 1. Download Dropbox.

Step 2. Run Windows Link Creator.exe

Step 3. Select /Dropbox/ App or Cloud Storage App path for "Place where you want your link"

Step 4. Select Folder you want to Sync-Link

Step 5. Update Files into Folder to test that the App Worked, and you still have your saved stuff on the Drive,

Step 6. Now Save Endless stuff in your Drive and it will write to Dropbox Cloud.

Step 7. all good!!!


Cheers, Happy Cloud Storaging Friends!!

-sw33tsp0t


Notes:
========================
Symbolic Link: Links Old Directory to New Directory Saved File(s) Path

Hard Link: Writes new Directory from old Directory

Directory Junction: Writes to both Old and New Paths